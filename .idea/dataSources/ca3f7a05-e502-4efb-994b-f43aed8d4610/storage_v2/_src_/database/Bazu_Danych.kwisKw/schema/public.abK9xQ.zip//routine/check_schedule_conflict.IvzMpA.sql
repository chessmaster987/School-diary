create function check_schedule_conflict() returns trigger
    language plpgsql
as
$$
DECLARE 
    teacher_name TEXT; 
    conflict_count INTEGER; 
BEGIN 
    SELECT full_name INTO teacher_name FROM Teacher WHERE employee_number = (SELECT employee_number FROM timetable WHERE timetable_id = NEW.timetable_id);
    
    SELECT COUNT(*) INTO conflict_count FROM Schedule 
    WHERE timetable_id = NEW.timetable_id
    AND day = NEW.day
	AND subject_number = NEW.subject_number 
    AND timetable_id = NEW.timetable_id
 	AND schedule_id <> NEW.schedule_id; --перевірка унікальності запису, що не дорівнює будь якому з вже існуючих
    IF conflict_count > 0 THEN 
        RAISE EXCEPTION 'Teacher % is already scheduled for lesson % on day %', teacher_name, NEW.timetable_id, NEW.day; 
    END IF; 
    
    RETURN NEW; 
END; 
$$;

alter function check_schedule_conflict() owner to postgres;

