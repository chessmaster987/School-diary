create function academic_performance_ranking(start_date date, end_date date, subject_num integer, class_num integer)
    returns TABLE(s_login character varying, s_avg_grade numeric, s_rank_avg_grade bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        student.login AS s_login,
        AVG(grade.grade) AS s_avg_grade,
        DENSE_RANK() OVER (ORDER BY AVG(grade.grade) DESC) AS s_rank_avg_grade
    FROM
        Grade
        INNER JOIN schedule ON grade.lesson_id = schedule.schedule_id
        INNER JOIN timetable ON schedule.timetable_id = timetable.timetable_id
        INNER JOIN subject ON timetable.subject_number = subject.subject_number
        INNER JOIN student ON grade.login = student.login
        INNER JOIN classes ON student.class_number = classes.class_number
    WHERE
        subject.subject_number = subject_num
        AND classes.class_number = class_num
    GROUP BY
        student.login;
END;
$$;

alter function academic_performance_ranking(date, date, integer, integer) owner to postgres;

