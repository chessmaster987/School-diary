create function statistics_poor_grades(start_date date, end_date date, class_num integer)
    returns TABLE(s_login character varying, subj_name character varying, s_num_poor_grade bigint, s_rank_poor_grade bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT  
        Student.login AS student_login, 
        Subject.subject_name AS subject, 
        COUNT(Grade.grade_number) AS marks_count, 
        DENSE_RANK() OVER (ORDER BY COUNT(Grade.grade_number) DESC) AS s_rank_poor_grade
    FROM 
        grade
        INNER JOIN student ON grade.login = student.login
        INNER JOIN schedule ON grade.lesson_id = schedule.schedule_id
        INNER JOIN timetable ON schedule.timetable_id = timetable.timetable_id
        INNER JOIN subject ON timetable.subject_number = subject.subject_number
        INNER JOIN classes ON student.class_number = classes.class_number
    WHERE 
        Grade.grade >= 1 AND Grade.grade <= 4 
        AND classes.class_number = class_num
    GROUP BY 
        Student.login, Subject.subject_name
    ORDER BY
		s_rank_poor_grade,
		Student.login, Subject.subject_name;
END;
$$;

alter function statistics_poor_grades(date, date, integer) owner to postgres;

