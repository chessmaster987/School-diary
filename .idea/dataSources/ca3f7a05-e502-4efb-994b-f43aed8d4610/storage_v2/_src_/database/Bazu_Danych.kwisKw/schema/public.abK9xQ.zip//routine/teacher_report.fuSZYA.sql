create function teacher_report(teacher_id integer, start_date date, end_date date)
    returns TABLE(teacher_name character varying, total_grades integer, total_lessons integer, avg_grade numeric, total_classes integer)
    language plpgsql
as
$$
BEGIN
--++
	SELECT full_name INTO teacher_name FROM Teacher WHERE employee_number = teacher_id;
--++
	SELECT COUNT(*) INTO total_grades
	FROM grade g
	INNER JOIN schedule s ON g.lesson_id = s.schedule_id
	INNER JOIN timetable t ON s.timetable_id = t.timetable_id
	WHERE t.employee_number = teacher_id
	AND g.date BETWEEN start_date AND end_date;
--++
	SELECT COUNT(DISTINCT homework_number) INTO total_lessons
	FROM homework
	WHERE lesson_id IN (SELECT lesson_id FROM schedule 
					INNER JOIN schedule s ON lesson_id = s.schedule_id
					INNER JOIN timetable t ON s.timetable_id = t.timetable_id
					WHERE t.employee_number = teacher_id)
	AND date BETWEEN start_date AND end_date;
--++
	SELECT ROUND(AVG(grade)::numeric, 2) INTO avg_grade FROM grade g 
	INNER JOIN schedule s ON g.lesson_id = s.schedule_id
	INNER JOIN timetable t ON s.timetable_id = t.timetable_id
    WHERE t.employee_number = teacher_id
    AND g.date BETWEEN start_date AND end_date;
--++	    
	SELECT COUNT(DISTINCT s.class_number) INTO total_classes
	FROM Schedule s
	INNER JOIN Timetable tt ON s.timetable_id = tt.timetable_id
	INNER JOIN Teacher t ON tt.employee_number = t.employee_number
	WHERE t.employee_number = teacher_id;
    
	RETURN NEXT;
	
END;
$$;

alter function teacher_report(integer, date, date) owner to postgres;

